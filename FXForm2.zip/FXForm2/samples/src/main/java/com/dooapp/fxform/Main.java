package com.dooapp.fxform;

import com.dooapp.fxform.samples.SimpleForm;
import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(SimpleForm.class);
    }
}
