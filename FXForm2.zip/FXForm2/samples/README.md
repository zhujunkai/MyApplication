# FXForm2 samples

This module is a collection of various samples demonstrating the usage of FXForm2. These samples are using the ControlsFX FXSampler.

To run the samples, just type at the root of the module :

    mvn exec:java

![alt text](https://github.com/dooApp/FXForm2/blob/master/samples/FXForm2%20Sampler.jpg)
