package com.dooapp.fxform.reflection.classcast;

/**
 * the SuperDevice use for testing.
 * <br>
 * Created at 13/12/13 17:28.<br>
 *
 * @author Bastien
 */
public class SuperDevice<T extends Device> {


}
