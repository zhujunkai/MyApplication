package com.dooapp.fxform.builder;

import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;

public class ScrollPaneBuilder {
    private ScrollPane scrollPane = new ScrollPane();
    public static ScrollPaneBuilder create() {
        return new ScrollPaneBuilder();
    }


    public ScrollPaneBuilder content(VBox vBox) {
        scrollPane.setContent(vBox);
        return this;
    }

    public ScrollPaneBuilder fitToWidth(boolean b) {
        scrollPane.setFitToWidth(b);
        return this;
    }

    public ScrollPane build() {
        return scrollPane;
    }
}
