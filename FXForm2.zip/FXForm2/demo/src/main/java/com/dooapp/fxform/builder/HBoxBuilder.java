package com.dooapp.fxform.builder;

import javafx.scene.Node;
import javafx.scene.layout.HBox;

public class HBoxBuilder {
    private HBox hBox = new HBox();
    public static HBoxBuilder create() {
        return new HBoxBuilder();
    }


    public HBox build() {
        return hBox;
    }

    public HBoxBuilder children(Node... nodes) {
        for (Node node : nodes){
            hBox.getChildren().add(node);
        }
        return this;
    }
}
