package com.dooapp.fxform.builder;

import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

public class SceneBuilder {
    private Scene scene = null;
    public static SceneBuilder create() {
        return  new SceneBuilder();
    }

    public SceneBuilder root(StackPane root) {
        scene = new Scene(root);
        return this;
    }

    public Scene build() {
        return scene;
    }
}
