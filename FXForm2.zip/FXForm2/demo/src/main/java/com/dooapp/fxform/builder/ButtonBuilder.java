package com.dooapp.fxform.builder;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import org.controlsfx.control.Notifications;

public class ButtonBuilder {
    private Button button = new Button();
    public static ButtonBuilder create() {
        return new ButtonBuilder();
    }


    public Button build() {
        return button;
    }

    public ButtonBuilder text(String validate) {
        button.setText(validate);
        return this;
    }

    public ButtonBuilder defaultButton(boolean b) {
        button.setDefaultButton(b);
        return this;
    }

    public ButtonBuilder onAction(EventHandler<ActionEvent> actionEventEventHandler) {
        button.setOnAction(actionEventEventHandler);
        return this;
    }
}
