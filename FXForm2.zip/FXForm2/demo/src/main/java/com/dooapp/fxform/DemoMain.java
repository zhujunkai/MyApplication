package com.dooapp.fxform;

import javafx.application.Application;

public class DemoMain {
    public static void main(String[] args) {
        Application.launch(Demo.class);
    }
}
