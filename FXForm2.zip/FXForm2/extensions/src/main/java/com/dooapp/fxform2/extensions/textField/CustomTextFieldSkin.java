package com.dooapp.fxform2.extensions.textField;

import javafx.beans.property.ObjectProperty;
import javafx.css.PseudoClass;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.TextField;
import javafx.scene.control.skin.TextFieldSkin;
import javafx.scene.layout.StackPane;
import javafx.scene.text.HitInfo;

public abstract class CustomTextFieldSkin extends TextFieldSkin {
    private static final PseudoClass HAS_NO_SIDE_NODE = PseudoClass.getPseudoClass("no-side-nodes");
    private static final PseudoClass HAS_LEFT_NODE = PseudoClass.getPseudoClass("left-node-visible");
    private static final PseudoClass HAS_RIGHT_NODE = PseudoClass.getPseudoClass("right-node-visible");
    private Node left;
    private StackPane leftPane;
    private Node right;
    private StackPane rightPane;
    private final TextField control;

    public CustomTextFieldSkin(TextField control) {
        super(control);
        this.control = control;
        this.updateChildren();
        this.registerChangeListener(this.leftProperty(), (a)->handleControlPropertyChanged("LEFT_NODE"));
        this.registerChangeListener(this.rightProperty(),  (a)->handleControlPropertyChanged("RIGHT_NODE"));
        this.registerChangeListener(control.focusedProperty(),  (a)->handleControlPropertyChanged("FOCUSED"));
    }

    public abstract ObjectProperty<Node> leftProperty();

    public abstract ObjectProperty<Node> rightProperty();

    protected void handleControlPropertyChanged(String p) {
        if (p == "LEFT_NODE" || p == "RIGHT_NODE") {
            this.updateChildren();
        }

    }

    private void updateChildren() {
        Node newLeft = (Node)this.leftProperty().get();
        if (newLeft != null) {
            this.getChildren().remove(this.leftPane);
            this.leftPane = new StackPane(new Node[]{newLeft});
            this.leftPane.setAlignment(Pos.CENTER_LEFT);
            this.leftPane.getStyleClass().add("left-pane");
            this.getChildren().add(this.leftPane);
            this.left = newLeft;
        }

        Node newRight = (Node)this.rightProperty().get();
        if (newRight != null) {
            this.getChildren().remove(this.rightPane);
            this.rightPane = new StackPane(new Node[]{newRight});
            this.rightPane.setAlignment(Pos.CENTER_RIGHT);
            this.rightPane.getStyleClass().add("right-pane");
            this.getChildren().add(this.rightPane);
            this.right = newRight;
        }

        this.control.pseudoClassStateChanged(HAS_LEFT_NODE, this.left != null);
        this.control.pseudoClassStateChanged(HAS_RIGHT_NODE, this.right != null);
        this.control.pseudoClassStateChanged(HAS_NO_SIDE_NODE, this.left == null && this.right == null);
    }

    @Override
    protected void layoutChildren(double x, double y, double w, double h) {
        double fullHeight = h + this.snappedTopInset() + this.snappedBottomInset();
        double leftWidth = this.leftPane == null ? 0.0D : this.snapSize(this.leftPane.prefWidth(fullHeight));
        double rightWidth = this.rightPane == null ? 0.0D : this.snapSize(this.rightPane.prefWidth(fullHeight));
        double textFieldStartX = this.snapPosition(x) + this.snapSize(leftWidth);
        double textFieldWidth = w - this.snapSize(leftWidth) - this.snapSize(rightWidth);
        super.layoutChildren(textFieldStartX, 0.0D, textFieldWidth, fullHeight);
        double rightStartX;
        if (this.leftPane != null) {
            rightStartX = 0.0D;
            this.leftPane.resizeRelocate(0.0D, 0.0D, leftWidth, fullHeight);
        }

        if (this.rightPane != null) {
            rightStartX = this.rightPane == null ? 0.0D : w - rightWidth + this.snappedLeftInset();
            this.rightPane.resizeRelocate(rightStartX, 0.0D, rightWidth, fullHeight);
        }

    }

    @Override
    public HitInfo getIndex(double x, double y) {
        double leftWidth = this.leftPane == null ? 0.0D : this.snapSize(this.leftPane.prefWidth(((TextField)this.getSkinnable()).getHeight()));
        return super.getIndex(x - leftWidth, y);
    }

    @Override
    protected double computePrefWidth(double h, double topInset, double rightInset, double bottomInset, double leftInset) {
        double pw = super.computePrefWidth(h, topInset, rightInset, bottomInset, leftInset);
        double leftWidth = this.leftPane == null ? 0.0D : this.snapSize(this.leftPane.prefWidth(h));
        double rightWidth = this.rightPane == null ? 0.0D : this.snapSize(this.rightPane.prefWidth(h));
        return pw + leftWidth + rightWidth;
    }

    @Override
    protected double computePrefHeight(double w, double topInset, double rightInset, double bottomInset, double leftInset) {
        double ph = super.computePrefHeight(w, topInset, rightInset, bottomInset, leftInset);
        double leftHeight = this.leftPane == null ? 0.0D : this.snapSize(this.leftPane.prefHeight(-1.0D));
        double rightHeight = this.rightPane == null ? 0.0D : this.snapSize(this.rightPane.prefHeight(-1.0D));
        return Math.max(ph, Math.max(leftHeight, rightHeight));
    }
}
