package com.dooapp.fxform2.extensions;

/**
 * User: Antoine Mischler <antoine@dooapp.com>
 * Date: 27/10/2017
 * Time: 14:02
 */
public enum AddressField {

    STREET, CITY, POSTCODE;

}
